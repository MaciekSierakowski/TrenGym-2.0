<template>
  <div id="app">
    <router-view></router-view>
    <p> &copy; Maciej Sierakowski 22078 Patryk Burda 22049 <RouterLink to = "/">TrenGym</RouterLink></p>
  </div>
</template>

<script>

export default {
  name: 'App',
  methods: {
    logout() {
      this.$store.dispatch('logout');
    },
  },
};
</script>
