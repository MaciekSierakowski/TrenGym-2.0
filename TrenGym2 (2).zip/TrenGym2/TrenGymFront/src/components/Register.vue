<template>
  <div class="bg-secondary text-light min-vh-100 d-flex flex-column justify-content-center align-items-center">
    <h2 class="text-center text-light mb-4">Zarejestruj się</h2>
    <div class="register-container">
      <form @submit.prevent="registerUser" class="container bg-dark border border-dark rounded">
        <div class="form-group">
          <label for="imie">Imię:</label>
          <input type="text" id="imie" v-model="user.imie" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="nazwisko">Nazwisko:</label>
          <input type="text" id="nazwisko" v-model="user.nazwisko" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="login">Login:</label>
          <input type="text" id="login" v-model="user.login" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="haslo">Hasło:</label>
          <input type="password" id="haslo" v-model="user.haslo" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" id="email" v-model="user.email" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="urodziny">Data urodzenia:</label>
          <input type="date" id="urodziny" v-model="user.urodziny" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="phone">Numer telefonu:</label>
          <input type="tel" id="phone" v-model="user.phone" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="karnet">Typ karnetu:</label>
          <input type="text" id="karnet" v-model="user.karnet" required class="form-control" />
        </div>
        <div class="form-group">
          <label for="dlugosc">Długość karnetu:</label>
          <input type="number" id="dlugosc" v-model="user.dlugosc" required class="form-control" />
        </div>
        <button type="submit" class="btn btn-primary mt-2 mb-2" style="margin-top: 10px; margin-left: 20%;">Zarejestruj się</button>
      </form>
      <div v-if="success" class="container mt-3">
        <p>Rejestracja przebiegła pomyślnie!</p>
        <router-link to="/login">
          <p>Zaloguj się</p>
        </router-link>
      </div>
    </div>
    <div v-if="error" class="container mt-3">
      <p>{{ error }}</p>
    </div>
  </div>
</template>
  
  <script>
  import axios from 'axios';
import { RouterLink } from 'vue-router';
  
  export default {
    data() {
      return {
        user: {
          imie: '',
          nazwisko: '',
          login: '',
          haslo: '',
          email: '',
          urodziny: '',
          phone: '',
          karnet: '',
         dlugosc: ''
        },
        success: false,
        error: ''
      }
    },
    methods: {
      async registerUser() {
        try {
          await axios.post('http://localhost:3000/api/users', this.user);
          this.success = true;
          this.error = '';
        } catch (error) {
          if (error.response && error.response.data) {
            this.error = error.response.data.error;
          } else {
            this.error = 'error';
          }
          this.success = false;
        }
      }
    }
  }
  </script>