<template>
  <div class="bg-secondary text-light min-vh-100 d-flex flex-column justify-content-center align-items-center">
    <button @click="logout" class="btn btn-danger">Wyloguj się</button>
    <div class="mt-5">
      <h2 class="mb-4">Panel użytkownika</h2>
      <div class="card">
        <div class="card-body">
          
          <p class="mt-3"><strong>Nick:</strong> {{ userData.login }}</p>
          <p><strong>Typ karnetu:</strong> {{ userData.Typ_karnetu }}</p>
          <p><strong>Długość karnetu:</strong> {{ userData.dni_do_wygasniecia }} dni</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userData: {},
    };
  },
  created() {
    const userData = JSON.parse(localStorage.getItem('userData'));
    if (userData) {
      this.userData = userData;
    } else {
      this.$router.push('/login');
    }
  },
  methods: {
    logout() {
      this.$store.dispatch('logout');
      this.$router.push('/');
    },
  },
};
</script>
