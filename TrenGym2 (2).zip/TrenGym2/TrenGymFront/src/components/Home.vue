<template>
  <div>
    <nav class="navbar bg-primary">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="./icons/logo.png" alt="Bootstrap" width="400" height="50">
        </a>
        <button v-if="isLoggedIn" @click="logout" class="btn btn-danger">Wyloguj się</button>
        <router-link v-else to="/login" class="btn btn-dark">Zaloguj się</router-link>
      </div>
    </nav>
  <div class="bg-secondary mx-auto">
    <div class="container">
    </div>
    <div class="bg-secondary text-light">
      <h2>Informacje ogólne</h2>
      <p>
        Witamy na Naszej Siłowni! Jesteśmy miejscem, które kocha promowanie zdrowego stylu życia i aktywności fizycznej. Nasza siłownia oferuje nowoczesne i kompleksowe podejście do treningu, które obejmuje zarówno aspekty fizyczne, jak i psychiczne.
      </p>
      <div>
        <h3>Nasze Cele:</h3>
        <ol>
          <li><strong>Zdrowie i Witalność:</strong> Chcemy wspierać naszych członków w osiąganiu doskonałego zdrowia i pełnej witalności poprzez regularne ćwiczenia i zdrową dietę.</li>
          <li><strong>Wsparcie dla Każdego:</strong> Bez względu na poziom zaawansowania, każdy jest mile widziany. Oferujemy różnorodne programy treningowe dostosowane do różnych umiejętności i celów.</li>
          <li><strong>Społeczność i Motywacja:</strong> Tworzymy przyjazne środowisko, gdzie ludzie mogą się wzajemnie wspierać. Motywujemy się nawzajem do osiągania lepszych wyników.</li>
          <li><strong>Profesjonalna Kadra:</strong> Nasza doświadczona kadra trenerska jest gotowa pomóc w opracowaniu spersonalizowanego planu treningowego, odpowiedzieć na pytania i motywować Cię na każdym kroku.</li>
        </ol>
      </div>
      <div>
        <h3>Nasza Infrastruktura:</h3>
        <ul>
          <li><strong>Nowoczesny Sprzęt:</strong> Posiadamy najnowszy sprzęt treningowy, który umożliwia skuteczne i bezpieczne treningi.</li>
          <li><strong>Sale Treningowe:</strong> Oferujemy różnorodne zajęcia grupowe w naszych specjalnie dostosowanych salach.</li>
          <li><strong>Strefa Relaksu:</strong> Po intensywnym treningu zapraszamy do strefy relaksu, gdzie możesz zregenerować siły.</li>
        </ul>
      </div>
      <p>
        <strong>Dołącz do Nas!</strong> Niezależnie od tego, czy jesteś nowicjuszem, czy doświadczonym sportowcem, nasza siłownia jest idealnym miejscem do osiągania swoich celów. Dołącz do naszej społeczności i rozpocznij podróż do zdrowszego i bardziej aktywnego życia już dziś!
      </p>
      <div>
        <h3>Karnet Open Siłownia TrenGym</h3>
        <h4>Korzyści karnetu:</h4>
        <ul>
          <li>Dostęp do wszystkich stref siłowni o każdej porze</li>
          <li>Treningi personalne z doświadczonymi trenerami</li>
          <li>Uczestnictwo w zajęciach grupowych</li>
          <li>Rabaty na produkty i usługi partnerów</li>
        </ul>
        <p>Dołącz do karnetu Open już dziś!</p>
      </div>
      <div>
        <h3>Karnet Poranny Siłownia TrenGym</h3>
        <h4>Korzyści karnetu:</h4>
        <ul>
          <li>Dostęp do wszystkich stref siłowni do godziny 13</li>
          <li>Treningi personalne z doświadczonymi trenerami</li>
          <li>Rabaty na produkty i usługi partnerów</li>
        </ul>
        <p>Dołącz do karnetu Porannego już dziś!</p>
      </div>
    </div>
  </div>
  </div>
</template>

<script>
import { RouterLink } from 'vue-router';

export default {
  data() {
    return {
      isLoggedIn: false,
    };
  },
  methods: {
    logout() {
      this.$store.dispatch('logout');
    },
  },
};
</script>
