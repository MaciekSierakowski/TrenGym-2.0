<template>
  <div class="bg-secondary text-light min-vh-100 d-flex flex-column justify-content-center align-items-center" style="height: 700px; width: 100%;">
    <h2 style="display: flex; justify-content: center; align-items: center; margin-top: 20px;" class="text-light">Zaloguj się</h2>
      <div class="form-container p-3" style="display: flex; justify-content: center; align-items: center;">
          <form @submit.prevent="handleLogin" class="bg-dark p-4 rounded">
            <div class="form-group m-1">
              <label for="login" class="text-primary">Login</label>
              <input v-model="loginValue" type="text" class="form-control" id="login" required />
            </div>
            <div class="form-group m-1">
              <label for="password" class="text-primary">Hasło</label>
              <input v-model="passwordValue" type="password" class="form-control" id="password" required />
            </div>
            <button type="submit" class="btn btn-primary" style="margin-left: 60px; margin-top: 5px;">Zaloguj się</button>
            <p class="text-light mt-3 m-1">Nie masz konta? <router-link to="/register">Zarejestruj się</router-link></p>
          </form>
      </div>
  </div>
  
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      loginValue: '',
      passwordValue: '',
    };
  },
  methods: {
    async handleLogin() {
      try {
        const response = await axios.post('http://localhost:3000/api/login', {
          login: this.loginValue,
          haslo: this.passwordValue,
        });

        if (response.data.success) {
          const userData = {
            id: response.data.id,
            login: response.data.user,
            Typ_karnetu: response.data.Typ_karnetu,
            dni_do_wygasniecia: response.data.dni_do_wygasniecia
          };

          // Zapisanie danych użytkownika w lokalnym magazynie przeglądarki
          localStorage.setItem('userData', JSON.stringify(userData));

          if (this.loginValue === 'admin' && this.passwordValue === 'admin') {
            this.$router.push('/dashboard');
          } else {
            this.$router.push('/user');
          }
        } else {
          alert('Zły login lub hasło');
        }
      } catch (error) {
        console.error(error);
        alert('error');
      }
    },
  },
};
</script>