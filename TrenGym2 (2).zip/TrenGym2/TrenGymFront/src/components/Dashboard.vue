<template>
  <div class="bg-secondary text-light min-vh-100 d-flex flex-column justify-content-center align-items-center">
    <button @click="logout" class="btn btn-danger justify-content-right align-items-right">Wyloguj się</button>
    <div class="mt-5">
      <h2 class="mb-4">Panel administratora</h2>
      <div class="mb-3">
        
        <input v-model="userId" type="number" placeholder="Wprowadź ID" class="form-control d-inline-block mx-2" style="width: 200px;">
        <button @click="getUserById" class="btn btn-primary">Wyświetl dane</button>
      </div>
      <div v-if="userData" class="card mt-3">
        <div class="card-body">
          <p><strong>Imię:</strong> {{ userData.Imię }}</p>
          <p><strong>Nazwisko:</strong> {{ userData.Nazwisko }}</p>
          <p><strong>Typ karnetu:</strong> {{ userData.Typ_karnetu }}</p>
          <p><strong>Długość karnetu:</strong> {{ userData.Pozostała_dlugosc_karnetu }} dni</p>
          <p><strong>Email:</strong> {{ userData.email }}</p>
          <p><strong>Data urodzenia:</strong> {{ userData.data_urodzenia }}</p>
          <p><strong>Numer telefonu:</strong> {{ userData.numer_telefonu }}</p>
        </div>
      </div>
      <div class="mt-3">
        <button @click="deleteUser" class="btn btn-danger">Usuń użytkownika</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      userId: null,
      userData: null,
    };
  },
  methods: {
    async getUserById() {
      try {
        const response = await axios.get(`http://localhost:3000/api/users/${this.userId}`);
        this.userData = response.data;
      } catch (error) {
        console.error(error);
        alert('Wystąpił błąd podczas pobierania danych użytkownika');
      }
    },
    async deleteUser() {
      try {
        await axios.delete(`http://localhost:3000/api/users/${this.userId}`);
        alert('Użytkownik został pomyślnie usunięty');
        this.userId = null;
        this.userData = null;
      } catch (error) {
        console.error(error);
        alert('Wystąpił błąd podczas usuwania użytkownika');
      }
    },
    logout() {
      this.$store.dispatch('logout');
      this.$router.push('/');
    }
  },
};
</script>
