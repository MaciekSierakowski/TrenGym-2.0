import { createStore } from 'vuex';

export default createStore({
  state: {
    isLoggedIn: false,
    isAdmin: false,
  },
  mutations: {
    login(state) {
      state.isLoggedIn = true;
    },
    logout(state) {
      state.isLoggedIn = false;
    },
    loginAsAdmin(state) {
      state.isAdmin = true;
    },
    logoutAdmin(state) {
      state.isAdmin = false;
    },
  },
  actions: {
    login({ commit }) {
      commit('login');
    },
    logout({ commit }) {
      commit('logout');
    },
  },
  modules: {},
});
