const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

// Połączenie z bazą danych 
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'trengym'
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('Połączono z bazą danych MySQL');
});

// Logowanie użytkownika
app.post('/api/login', (req, res) => {
  const login = req.body.login;
  const haslo = req.body.haslo;

  const sql = 'SELECT * FROM uzytkownicy WHERE login = ? AND haslo = ?';
  const params = [login, haslo];

  db.query(sql, params, (error, results) => {
    if (error) {
      res.status(500).json({ success: false, error: 'Błąd serwera' });
      return;
    }

    if (results.length === 0) {
      res.status(401).json({ success: false, error: 'Nieprawidłowy login lub hasło' });
      return;
    }

    const user = results[0];

    res.status(200).json({
      success: true,
      id: user.id,
      user: user.login,
      Typ_karnetu: user.Typ_karnetu,
      dni_do_wygasniecia: user.Pozostała_dlugosc_karnetu
    });
  });
});

// Pobieranie wszystkich użytkowników
app.get('/api/users', (req, res) => {
  db.query('SELECT * FROM uzytkownicy', (err, results) => {
    if (err) {
      res.status(500).json({ error: 'Błąd serwera. Spróbuj ponownie później.' });
      throw err;
    }
    res.status(200).json(results);
  });
});

// Wyświetlanie szczegółów użytkownika
app.get('/api/users/:id', (req, res) => {
  const userId = req.params.id;
  db.query('SELECT * FROM uzytkownicy WHERE id = ?', [userId], (err, results) => {
    if (err) {
      res.status(500).json({ error: 'Błąd serwera. Spróbuj ponownie później.' });
      throw err;
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Nie znaleziono użytkownika o podanym identyfikatorze.' });
    }
    res.status(200).json(results[0]);
  });
});

// Dodawanie nowego użytkownika
app.post('/api/users', (req, res) => {
  const { imie, nazwisko, login, haslo, email, urodziny, phone, karnet, dlugosc } = req.body;
  db.query('INSERT INTO uzytkownicy (Imię, Nazwisko, login, haslo, email, data_urodzenia, numer_telefonu, Typ_karnetu, Pozostała_dlugosc_karnetu) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [imie, nazwisko, login, haslo, email, urodziny, phone, karnet, dlugosc], (err) => {
      if (err) {
        res.status(500).json({ error: 'Błąd serwera. Nie udało się dodać nowego użytkownika.' });
        throw err;
      }
      res.status(200).json({ success: true, message: 'Nowy użytkownik został pomyślnie dodany.' });
    });
});

// Edycja użytkownika
app.put('/api/users/:id', (req, res) => {
  const userId = req.params.id;
  const { imie, nazwisko, login, haslo, email, urodziny, phone } = req.body;
  db.query('UPDATE uzytkownicy SET Imię=?, Nazwisko=?, login=?, haslo=?, email=?, data_urodzenia=?, numer_telefonu=? WHERE id=?',
    [imie, nazwisko, login, haslo, email, urodziny, phone, userId], (err) => {
      if (err) {
        res.status(500).json({ error: 'Błąd serwera. Nie udało się zaktualizować użytkownika.' });
        throw err;
      }
      res.status(200).json({ success: true, message: 'Użytkownik został pomyślnie zaktualizowany.' });
    });
});

// Usuwanie użytkownika
app.delete('/api/users/:id', (req, res) => {
  const userId = req.params.id;
  db.query('DELETE FROM uzytkownicy WHERE id = ?', [userId], (err) => {
    if (err) {
      res.status(500).json({ error: 'Błąd serwera. Nie udało się usunąć użytkownika.' });
      throw err;
    }
    res.status(200).json({ success: true, message: 'Użytkownik został pomyślnie usunięty.' });
  });
});

app.listen(port, () => {
  console.log(`Serwer działa na http://localhost:${port}`);
});
